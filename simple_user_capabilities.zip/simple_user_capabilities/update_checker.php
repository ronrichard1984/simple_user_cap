<?php 
add_filter( 'site_transient_update_plugins', 'wprp_extend_filter_update_plugins' );
add_filter( 'transient_update_plugins', 'wprp_extend_filter_update_plugins' );
function wprp_extend_filter_update_plugins( $update_plugins ) {
 //echo "<pre>"; print_r($update_plugins);exit;
	if ( ! is_object( $update_plugins ) )
			return $update_plugins;

	if ( ! isset( $update_plugins->response ) || ! is_array( $update_plugins->response ) )
		$update_plugins->response = array();

	// Do whatever you need to see if there's a new version of your plugin
	// Your response will need to look something like this if it's out of date:
	$update_plugins->response['simple_user_capabilities/user_access.php'] = (object)array(
			'slug'         => 'simple_user_capabilities', // Whatever you want, as long as it's not on WordPress.org
			'new_version'  => '1.1', // The newest version
			'url'          => 'https://github.com/humanmade/wp-remote-sample-plugin', // Informational
			'package'      => 'https://github.com/humanmade/wp-remote-sample-plugin/archive/0.2.zip', // Where WordPress should pull the ZIP from.
		);

	return $update_plugins;
}


class myPluginUpdateChecker{
    protected static $plugin_slug;
    protected static $api_url;
    protected static $current_version;

    
    public function init($api_url=null, $plugin_slug=null, $current_version=null){
        
        $body = wp_remote_get($api_url);
        echo "<pre>"; print_r($body);

        //add_filter('wp_plugin_update_row', array($this,'customize_plugin_update_data', 11,2));
        //add_filter('plugin_row_meta', array($this,'plugin_update_notification'), 10, 2);
        //add_filter('auto_update_plugin', array($this,'enable_automatic_plugin_updates'), 10, 2);
       // add_filter('plugin_auto_update_setting_html', array($this,'plugin_auto_update_setting_html'), 10, 3);

    }

    public function customize_plugin_update_data($data, $response){
        $target_plugin = 'simple_user_capabilities/user_access.php';
        if($target_plugin===$response->slug){
            $data['update']=1;
        }
        return $data;
    }

    function plugin_auto_update_setting_html($html, $plugin_file, $plugin_data) {
        $target_plugin = 'simple_user_capabilities/user_access.php';
       //$target_plugin = 'akeebabackupwp/akeebabackupwp.php';
        //$target_plugin = 'user-role-editor-pro/user-role-editor-pro.php';
        // Check if the current plugin matches the target plugin
        if ($plugin_file === $target_plugin) {
            //echo "<pre>"; print_r($plugin_data);exit;
            $html = __( 'Auto-updates are not available for this plugin.', 'my-plugin' );
        }
    
        return $html;
    }

    public function plugin_update_notification($plugin_meta, $plugin_file){
        $target_plugin = 'simple_user_capabilities/user_access.php';
        if($plugin_file==$target_plugin){
            $notice = '<span style="color: #dc3232; font-weight: bold;">There is a new version of My Plugin available! Click <a href="' . admin_url('update.php?action=upgrade-plugin&plugin=' . urlencode($target_plugin)) . '">here</a> to update.</span>';

            $plugin_meta[] = $notice;
        }
        return $plugin_meta;
    }


    public function enable_automatic_plugin_updates($update, $item) {
        $plugin_slug = 'simple_user_capabilities/user_access.php';
        //echo "<pre>";
        //print_r($item);
        // Check if the plugin matches the desired plugin
        if ($item->id === $plugin_slug) {
            //echo "<pre>"; print_r($item);exit;
            // Enable automatic updates for the plugin
            return true;
        }
//exit;
        return $update;
    }

}

$update_checker = new myPluginUpdateChecker();
$update_checker->init()

?>