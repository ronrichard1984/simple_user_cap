<?php
/*
Plugin Name: Simple User Capabilities
Description: A plugin that will give menu's access for the user
Version: 1.0
Author: Md Tanvir Ahamed
*/
require_once(plugin_dir_path(__FILE__).'user_grid.php');
require_once(plugin_dir_path(__FILE__).'capabilities.php');

require_once(plugin_dir_path(__FILE__).'update_checker.php');
$update_checker->init();

class simple_user_cap{
  public function __construct(){
    add_action('admin_menu', array($this, 'simple_cap_menu'));
    add_action('wp_ajax_user_capabilities', array($this, 'get_user_capabilities'));
    add_action('wp_ajax_nopriv_user_capabilities',  array($this, 'get_user_capabilities'));

    add_action('wp_ajax_submit_capabilities', array($this,'submit_capabilities'));
    add_action('wp_ajax_nopriv_submit_capabilities', array($this,'submit_capabilities'));

    add_action('wp_ajax_reset_capability', array($this, 'reset_capability'));
    add_action('wp_ajax_nopriv_reset_capability', array($this, 'reset_capability'));

    add_action('admin_enqueue_scripts',  array($this, 'simple_capabiities_scripts'));

    register_activation_hook(__FILE__, array($this,'user_capabilities_record'));

  }

  public function user_capabilities_record(){

    global $table_prefix, $wpdb;

    $tableName = $table_prefix.'simple_user_cap';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS $tableName(
      id INT(11) NOT NULL AUTO_INCREMENT,
      user_id INT(22) NOT NULL DEFAULT '0',
      capabilities_log TEXT NULL,
      created DATETIME NULL,
      PRIMARY KEY (id) 
    ) $charset_collate;";

    require_once(ABSPATH.'wp-admin/includes/upgrade.php');
    dbDelta( $sql );

  }

  public function submit_capabilities(){

    global $wpdb;
    $user_id = $_REQUEST['targeted_user'];
    $user = get_user_by("ID", $user_id);
    //echo "<pre>"; print_r(get_userdata($user_id));exit;
    
    if($user->roles){
      $data = array(
        'user_id' => $user_id,
        'capabilities_log' => json_encode($user->roles),
        'created' => "now()"
      );
      $wpdb->insert($wpdb->prefix.'simple_user_cap',$data );
    }
    
    $user->remove_all_caps();
    $selected_caps = $_POST['user_caps'];
    foreach($selected_caps as $cap){
      $user->add_cap($cap);
    }

    echo json_encode(array('message'=>"Successfully submited", 'error'=>false));
    exit;

    $userallcaps = get_user_meta( $user_id, $wpdb->get_blog_prefix() . 'capabilities' );
    $userLevel = get_user_meta( $user_id, $wpdb->get_blog_prefix() . 'user_level' );
    //echo "<pre>"; print_r($user->allcaps);exit;
    //rlr_capabilities
    echo $wpdb->get_blog_prefix();exit;
    exit;
  }

  public function reset_capability(){
    global $table_prefix, $wpdb;
    $user_id = $_REQUEST['user_id'];
    $user = get_user_by("ID", $user_id);
    
    $table = $table_prefix."simple_user_cap";

    $existing_data = $wpdb->get_row( "SELECT * FROM $table WHERE user_id=$user_id");
    if($existing_data){
      $user_roles = json_decode($existing_data->capabilities_log);
      foreach($user_roles as $role){
        $user->add_role($role);
      }
    }
    exit;
  }

  public function simple_capabiities_scripts(){
    wp_enqueue_style( 'user-cap-admin-styles', plugins_url( 'assets/css/admin-styles.css', __FILE__ ),'','1.7' );
    wp_enqueue_style( 'bootstrap-styles', 'https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css' );
    wp_enqueue_style( 'bootstrap-select-styles', 'https://cdn.jsdelivr.net/npm/bootstrap-select@1.14.0-beta3/dist/css/bootstrap-select.min.css' );
   
    wp_enqueue_script( 'popper-scripts', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.3/umd/popper.min.js', array( 'jquery' ), '1.0', true );
    wp_enqueue_script( 'bootstrap-scripts', 'https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/js/bootstrap.min.js', array( 'jquery' ), '1.0', true );
    wp_enqueue_script( 'bootstrap-select-scripts', 'https://cdn.jsdelivr.net/npm/bootstrap-select@1.14.0-beta3/dist/js/bootstrap-select.min.js', array( 'jquery' ), '1.0', true );
    wp_enqueue_script( 'user-cap-scripts', plugins_url( 'assets/js/admin-scripts.js', __FILE__ ), array( 'jquery' ), '3.6', true );

}


  public function get_user_capabilities(){
    $capabilities  = new capabilities();
    $capabilities->custom_capabilities_settings_callback(); 
  }

  public function simple_cap_menu(){
    
    add_submenu_page(
      'users.php',
      'Simple User Capabilities',
      'Simple Capabilities',
      'manage_options',
      'simple_user_cap',
      array($this,'render_admin_page')
      );
  }

  public function render_admin_page(){
    if($_REQUEST['user_id']){
      $user_id = $_REQUEST['user_id'];
      $user = get_user_by("ID", $user_id);
      $roles = array('author','subscriber');
      foreach($roles as $role){
        //$user->add_role($role);
      }
      $user_data = get_userdata($user_id);
      echo "<pre>"; print_r($user_data); exit;
    }
    ?>
    <!-- The Modal -->
    <div id="myModal" class="userAccess-modal">
      <!-- Modal content -->
      <div class="userAccess-modal-content">
        <div class="userAccess-modal-header">
          <span class="close">&times;</span>
          <h2>Modal Header</h2>
        </div>
        <div class="userAccess-modal-body">
          <p>Some text in the Modal Body</p>
          <p>Some other text...</p>
        </div>
      </div>
    </div>

    <!-- Modal for only simple informational messages (success or error)-->
    <div class="modal fade" id="modal_alert" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Message</h5>
            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <p>Modal Body</p>
          </div>
        </div>
      </div>
    </div>

    <div id="success-popup" class="alert alert-success alert-dismissible fade show in flash_message">
      <h4 class="alert-heading"><b>Message</b></h4>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
      <hr>
      <div id="success-view-message">OK Done</div>
    </div>

    <div class="wrap">
        <h2>User List</h2>
        <?php 
          $user_grid = new simple_cap_users();
          $user_grid->prepare_items();
          $user_grid->display(); 
        ?>
    </div>
    <?php
  }

}

new simple_user_cap();

